//.........create async login function inside that write below commented part........//
    
//...........get the password and email...........//
    
    // let pass = document.getElementById('pass');
    // let em = document.getElementById('em');
    // if((em.value.length&&pass.value.length)==0){
    //     alert("Please Enter login details");
    // }
//..........create an object.............//

    // let user_data = {
    //     username: em.value,
    //     password: pass.value
    // }
    // let data = JSON.stringify(user_data);
    
//.........call post method...........//

    // let res = await fetch("http://localhost:3000/login", {
    //     method: "POST",
    //     body: data,
    //     headers: {
    //         "Content-Type": "application/json",
    //     },
    // })


//--------store response and token--------//

    // res = await res.json();
    // let token = res.token;


    