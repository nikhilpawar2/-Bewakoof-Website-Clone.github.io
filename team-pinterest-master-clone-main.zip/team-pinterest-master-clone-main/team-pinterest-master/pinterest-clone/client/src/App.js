

import Routers from "./Routes/Route";

function App() {
  return (
    <div >
      <Routers/>
     
    </div>
  );
}

export default App;
