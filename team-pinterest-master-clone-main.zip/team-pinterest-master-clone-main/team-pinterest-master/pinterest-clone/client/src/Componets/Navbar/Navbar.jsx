import React from 'react'
import NavbarCard from './NavbarCard'
//import NavbarCard from "./NavbarCard"

const Navbar = () => {
  return (
    <div className='sticky top-0 z-20 w-full'>
      <NavbarCard />
      
    </div>
  )
}
//
export default Navbar
