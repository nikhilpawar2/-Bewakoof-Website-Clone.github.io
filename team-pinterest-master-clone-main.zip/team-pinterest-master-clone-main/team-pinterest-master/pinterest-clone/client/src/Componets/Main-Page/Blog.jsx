import React from "react";
// import "./About.css";

import { Navbarm } from "./Navbarm";

export const Blog = () => {
  return (
    <div>
      <Navbarm />
      <h1>Hii</h1>
    </div>
  );
}