import React from "react";
// import "./About.css";

import { Navbarm } from "./Navbarm";

export const Business = () => {
  return (
    <div>
      <Navbarm />
      <h1>Hii</h1>
    </div>
  );
};
