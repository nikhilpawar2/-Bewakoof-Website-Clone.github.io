import React from "react";
// import "./About.css";

import { Navbar } from "./Navbarm";

export const Signup = () => {
  return (
    <div>
      <Navbar />
      <h1>Hii</h1>
    </div>
  );
};