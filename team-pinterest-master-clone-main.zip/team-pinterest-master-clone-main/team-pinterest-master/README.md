# team-Pinterest
this is our Unit-5 construct week project at Masai School and we are creating pinterest Clone.
